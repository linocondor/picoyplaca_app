<?= $this->extend('Layouts/default') ?>

<?= $this->section('title') ?>Resultado de la Consulta<?= $this->endSection() ?>

<?= $this->section('content') ?>
<div class="card is-hidden1">
    <div class="card-header"><p class="card-header-title">Resultado de la Consulta</p></div>
        

        <div class="card-content"><div class="content">

            <div class="container">
                
                
                    

                    
                    <div class="text is-size-6 has-text-centered">
                        <h1><b>Resultado de la consulta acerca del horario de circulación respecto al Pico y Placa</b></h1>
                        <p>Si deseas consultar si tienes permiso para circular en tu vehículo, porfavor digita tu número de placa, e ingresa la hora y la fecha en la cual deseas circular. </p>
                    </div>


                    

                

                    
                
            </div>


        </div>
    </div>           


</div>






<?= $this->endSection() ?>