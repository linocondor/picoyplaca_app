<nav class="navbar has-background-black" role="navigation" aria-label="main navigation">
  <div class="navbar-brand has-text-white">
      <a class="" href="<?= site_url("Archivos/index")?>">
        <img  width="200"  src="<?= site_url('images/pico.png')?>"  alt="profile image" >  
      </a>
  
  

    <a role="button" class="navbar-burger" aria-label="menu" aria-expanded="false" data-target="navbarBasicExample">
      <span aria-hidden="true"></span>
      <span aria-hidden="true"></span>
      <span aria-hidden="true"></span>
    </a>
  </div>

  <div id="navbarBasicExample" class="navbar-menu">
    <div class="navbar-start">
      

      

      

      </div>
    </div>
<!-- //COLOCAR EN LA PARTE DERECHA DE LA barra de  NAVEGACION -->
    <div class="navbar-end">
                     
      
      
       

      
      
        <div class="navbar-item">
          <div class="buttons">
            <a class="button is-primary has-text-black has-background-white-bis	 " href="<?= site_url("/")?>">
            
            <span>Nueva Consulta</span>
            <span class="icon is-small is-left">
            <i class="fas fa-plus-square"></i>
                    </span>
            </a>
            
          </div>
        </div>
      

    </div>
  </div>
</nav>


