<footer class="footer">
  <div class="content has-text-centered">
    <p>
      <strong>Pico Y Placa v. 1.0 - Lino Cóndor</strong></p>
  </div>
</footer>